<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SitevisitBoundary extends Model
{
    use HasFactory;


    protected $table = "sitevisit_boundaries";
}
