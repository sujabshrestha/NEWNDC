<?php

use Illuminate\Support\Facades\Route;

Route::group([
    'prefix' => config('clientRoute.prefix.api'),
    'namespace' => config('clientRoute.namespace.api'),
],
function(){

  

});

