<?php

namespace SiteVisit\Repositories;


interface SiteVisitInterface
{


}
