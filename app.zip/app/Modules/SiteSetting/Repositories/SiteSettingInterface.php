<?php

namespace SiteSetting\Repositories;


interface SiteSettingInterface
{


}
