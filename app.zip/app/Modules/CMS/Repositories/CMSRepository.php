<?php namespace Auth\Repositories;

use Illuminate\Support\Facades\Auth;

use CMS\Repositories\CMSInterface;

class CMSRepository implements CMSInterface {



}
