<?php

namespace CMS\Repositories;


interface CMSInterface
{


}
