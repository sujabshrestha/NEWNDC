<?php

namespace CMS\Http\Controllers\Backend;

use App\GlobalServices\ResponseService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Brian2694\Toastr\Facades\Toastr;
use CMS\Models\Bank;
use CMS\Models\Branch;
use Files\Repositories\FileInterface;
use Yajra\DataTables\Facades\DataTables;

class BranchController extends Controller
{
    
    public function valuationForm(){
        return view('CMS::backend.design.valuation');
    }

    public function buildingValuationForm(){
        return view('CMS::backend.design.buildingvaluation');
    }
}
